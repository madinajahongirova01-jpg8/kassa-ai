---
name: Kassa AI Ledger System
colors:
  surface: '#fafaf5'
  surface-dim: '#dadad5'
  surface-bright: '#fafaf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4ef'
  surface-container: '#eeeee9'
  surface-container-high: '#e8e8e4'
  surface-container-highest: '#e2e3de'
  on-surface: '#1a1c19'
  on-surface-variant: '#3f4944'
  inverse-surface: '#2f312e'
  inverse-on-surface: '#f1f1ec'
  outline: '#6f7974'
  outline-variant: '#bec9c3'
  surface-tint: '#156b55'
  primary: '#07644e'
  on-primary: '#ffffff'
  primary-container: '#2e7d66'
  on-primary-container: '#d3ffed'
  inverse-primary: '#88d6ba'
  secondary: '#49645b'
  on-secondary: '#ffffff'
  secondary-container: '#c8e6db'
  on-secondary-container: '#4d685f'
  tertiary: '#7b4e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#9c6400'
  on-tertiary-container: '#fff3e9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a4f2d6'
  primary-fixed-dim: '#88d6ba'
  on-primary-fixed: '#002118'
  on-primary-fixed-variant: '#00513f'
  secondary-fixed: '#cbe9de'
  secondary-fixed-dim: '#afcdc2'
  on-secondary-fixed: '#042019'
  on-secondary-fixed-variant: '#314c44'
  tertiary-fixed: '#ffddb6'
  tertiary-fixed-dim: '#ffb95a'
  on-tertiary-fixed: '#2a1800'
  on-tertiary-fixed-variant: '#643f00'
  background: '#fafaf5'
  on-background: '#1a1c19'
  surface-variant: '#e2e3de'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  tabular-ledger:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative yet accessible fintech language tailored for everyday merchants, market stall operators, and enterprise shopkeepers across Tajikistan. It bridges the traditional paper ledger (*дафтари насия*) and automated voice-driven bookkeeping through the tangible metaphor of the **Smart Receipt**.

The aesthetic merges contemporary utility with tactile paper craft. It relies on clean, high-contrast layouts, structured tabular geometry, and mechanical ledger markers—such as subtle perforated dividers, serrated torn-paper trims, and rubberized receipt stamps—without resorting to heavy skeuomorphic clutter. 

Key pillars:
- **Calm Authority & Financial Trust:** High-contrast forest emerald tones combined with warm off-white surfaces instill immediate stability, eliminating the anxiety of unpaid credit balances.
- **Vernacular Tactility:** The ledger feels like physical financial paper—grounded, crisp, and verifiable.
- **Bi-Scriptural Clarity:** Type scales and vertical metrics are calibrated specifically for Cyrillic legibility across both Tajik alphabet nuances (ҳ, ӣ, ӯ, ғ, қ, ҷ) and universal Latin/Arabic numerals.

## Colors

The palette balances institutional banking credibility with the ambient warmth of natural parchment. 

### Color Architecture
- **Primary Vivid Emerald (`#2E7D66`):** The primary brand anchor. Used for primary interactions, voice-listening states, positive cash balance flows, and verified income entries.
- **Primary Deep Forest (`#0F2A23`):** High-density canvas contrast. Used for top app bars, primary action buttons, data visualization baselines, and primary typography.
- **Warm Amber Action (`#E39A2D`):** High-intent indicator. Dedicated to upcoming debt maturities (*мӯҳлати наздик*), voice capture triggers, audio waveforms, and debt reminder actions.
- **Alert Coral (`#C8553D`):** Dedicated exclusively to debit risks, overdue defaults (*қарзи таъхирёфта*), and cancellation states.
- **Canvas Base (`#F7F7F2`):** A warm, low-glare off-white background that prevents optical eye fatigue in outdoor bazaars and brightly lit retail shops.
- **Pure Paper Card (`#FFFFFF`):** High-clarity elevated surfaces representing individual receipts, modal drawers, and balance sheets.
- **Hairline Border (`#E2E5DD`):** Structural division line tone calibrated to replicate micro-perforated receipt stock.

### Semantic Status Pairings
- **Income / Paid (`#2E7D66`):** Background `rgba(46, 125, 102, 0.08)`, border `rgba(46, 125, 102, 0.2)`.
- **Pending / Due Soon (`#E39A2D`):** Background `rgba(227, 154, 45, 0.1)`, border `rgba(227, 154, 45, 0.25)`.
- **Overdue / Expired (`#C8553D`):** Background `rgba(200, 85, 61, 0.08)`, border `rgba(200, 85, 61, 0.2)`.

## Typography

The type system balances bold, modern geometry with utilitarian data density:

- **Headings (Plus Jakarta Sans):** Geometric clarity with wide apertures and solid proportions. Ensures Cyrillic diacritics sit cleanly above cap-heights without clipping or visual weight imbalances.
- **Body & Controls (Inter):** Highly legible, neutral sans-serif designed for micro-screen legibility and high information density. Inter's tall x-height preserves character differentiation in rapid transaction reviews.
- **Tabular Figures & Currency:** All currency amounts (*смн / сомонӣ*) must enforce `font-feature-settings: "tnum" 1, "cv05" 1` to guarantee precise vertical decimal alignment in debt ledgers.
- **Micro Labels:** Rendered in small caps with subtle tracking to mimic industrial thermal printing stamps on invoice metadata.

## Layout & Spacing

The layout is built upon an 8-point base grid designed for speed and rapid touch input during business hours.

### Viewport Structures
- **Mobile Handheld (360px – 767px):** Single-column stream with a persistent sticky bottom action bar (Voice Ledger capture button + quick sum). Margin: `1rem`, Column Gutter: `1rem`. Max touch target size: 48px minimum.
- **Tablet / Counter POS (768px – 1023px):** Split-view master-detail architecture. The left column (40% width) lists customers and overdue balances (*Рӯйхати муштариён*); the right column (60% width) renders the active Smart Receipt and transaction history.
- **Desktop Dashboard (1024px+):** Constrained container (1280px max-width) with a 12-column grid. Used for weekly auditing, batch debt collection, and tax export sheets.

### Spacing Cadence
- Use `space-xs` (4px) exclusively for icon-to-label inline offsets and tag padding.
- Use `space-sm` (8px) for compact cell padding and card internal metadata stacks.
- Use `space-md` (16px) for universal card padding, form field gaps, and list group separators.
- Use `space-lg` (24px) for section headers and receipt perforated divider margins.
- Use `space-xl` (40px) for primary layout boundaries and floating action positioning.

## Elevation & Depth

Rather than relying on heavy, dark drop shadows, the design system creates depth through **tonal paper layering** and soft, tinted ambient occlusion. This reproduces the physical feel of slips resting on a merchant's wooden counter.

### Elevation Hierarchy
- **Level 0 (Canvas Base):** Flat `#F7F7F2`. Background for screens and global feeds.
- **Level 1 (Card & Paper Ledger):** Pure `#FFFFFF` surface bordered by a 1px solid hairline (`#E2E5DD`). Shadow: `0 1px 3px rgba(15, 42, 35, 0.04), 0 4px 12px rgba(15, 42, 35, 0.02)`.
- **Level 2 (Active Cards & Floating Drawer):** Elevated receipt sheet during active review or debt creation. Shadow: `0 8px 24px rgba(15, 42, 35, 0.08), 0 2px 6px rgba(15, 42, 35, 0.03)`.
- **Level 3 (Modal & Voice Overlay):** Full floating overlay. Features a tinted backdrop blur (`rgba(15, 42, 35, 0.4)` with 8px blur) and container shadow: `0 16px 40px rgba(15, 42, 35, 0.16)`.

### Decorative Physical Metaphors
- **Micro-perforation Line:** Rendered via CSS `border-top: 1.5px dashed #E2E5DD` with `space-sm` margins.
- **Torn Serrated Edge:** Card footer elements utilize an inverted triangular mask or pure SVG zigzag bottom edge (`height: 6px`) to give receipts a distinct physical tear line.

## Shapes

The shape system employs consistent, rounded geometry (level 2) that feels sturdy and balanced.

- **Primary Cards & Modals:** Standardized corner radius of `16px` (`rounded-xl` in this scale). Cards that include the serrated receipt bottom edge maintain `16px` at the top corners and square `0px` cuts at the bottom tear line.
- **Action Buttons & Form Inputs:** Set to `8px` corner radius. Provides an intentional, punchy balance that signals clickability without feeling playful.
- **Status Pills & Action Chips:** Full circular pill rounding (`9999px`) to immediately distinguish category badges from actionable form containers.
- **Ledger Stamps:** 4px radius with an intentional 2-degree rotational tilt to evoke an ink-stamped audit verification (*ПАРДОХТ ШУД / ТАСДИҚ*).

## Components

### Buttons
- **Primary Transactional:** Deep Forest background (`#0F2A23`), crisp white text, 8px border radius, 48px height for thumb ergonomics. Hover/Active transforms to `#163A31`.
- **Voice Bookkeeping Button:** Vivid Green (`#2E7D66`) circular trigger (64px) with Amber (`#E39A2D`) pulsating aura during active audio recording.
- **Secondary Ledger Action:** Warm Canvas tint (`#FFFFFF`) with a 1px border of `#E2E5DD`, text color `#0F2A23`.

### The Smart Receipt Card
- **Structure:** Pure white card surface with top metadata (Merchant name, date, customer phone).
- **Body:** Dashed divider line (`#E2E5DD`), tabular row listing items or voice-transcribed note, and high-visibility total amount in Сомонӣ.
- **Footer:** Visual serrated jagged paper pattern at base, flanked by an SVG barcode marker and an automated audit timestamp.

### Status Badges (Насия Statuses)
- **Пардохт шуд (Paid):** Emerald tint background, solid `#2E7D66` text, 12px typography, 4px vertical / 10px horizontal padding, pill radius.
- **Мӯҳлати наздик (Due Soon):** Amber tint background, `#E39A2D` text, subtle amber warning dot icon.
- **Қарзи гузашта (Overdue):** Coral tint background, `#C8553D` text, high-contrast bold warning weight.

### Input Fields & Search
- Background `#FFFFFF`, 1px border `#E2E5DD`, 8px corner radius.
- Focus state: 1.5px border of `#2E7D66` with zero optical ring blowout. Includes integrated voice dictation mic icon on the right edge.

### Customer Debt Row (Рӯйхати қарздорон)
- 64px list item height with 1px bottom divider line. 
- Left side: Avatar circle with merchant or customer initials, followed by name and phone number.
- Right side: Bold tabular debt balance in `#0F2A23` or `#C8553D`, followed by the payment due date in small-caps label style.